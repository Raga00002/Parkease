class Profile {
  Profile(
      {required this.name,
      required this.contactNumber,
      required this.emailID,
      required this.carPlate,
      required this.currentBalance,
      required this.dob});
  String name;
  String contactNumber;
  String emailID;
  String carPlate;
  String currentBalance;
  String dob;
}
